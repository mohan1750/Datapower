console.error('admin')

const sm = require('service-metadata')
const hm = require('header-metadata')
const urlopen = require('urlopen')

const method = sm.protocolMethod.toLowerCase();
const url = require('url').parse(sm.URLIn, false)
const headers = hm.current.headers
let req = {
  method: method,
  path: url.pathname.replace(/\/$/, ''),
  headers: headers,
  params: {},
  urlObj: url,
  url: sm.URLIn,
  protocol: sm.protocol,
  hostname: headers.Host,
  hostip: url.hostname,
  clientip: sm.transactionClient,
  trnId: sm.transactionId,
  routingUrl: sm.routingUrl
}
if (url.query) {
  req.query = url.query
  req.params = req.params || {}
  req.params.query = require('querystring').parse(url.query)
}
req.search = url.search || ''

const res = {
  status: function(sts) { hm.response.statusCode = sts },
  headers: function(name, value) { hm.response.set(name, value) },
  send: function(data) { session.output.write(data) }
}

const config = require('local:///ondisk/SAPF_Gatekeeper/scripts/config')


function errorResponse(error) {
  sm.mpgw.skipBackside = true
  let httpCode = error.httpCode || '500'
  let httpReason = error.httpReason || 'Internal Server Error'
  let errorDetails = {
    httpCode: httpCode,
    httpReason: httpReason,
    details: error.details
  }
  let ctxANZERROR = session.name('ANZERROR') || session.createContext('ANZERROR')
  ctxANZERROR.setVar('error', errorDetails)
  throw new Error()
}


/*************************************/

sm.mpgw.skipBackside = true

function authenticate() {
  const validUsers = ['parasurvadmin']
  let auth, user
  try {
    auth = (new Buffer(req.headers.Authorization.replace(/^Basic /, ''), 'base64')).toString()
    user = auth.split(':')[0]
    if (validUsers.indexOf(user) < 0) throw('Invalid user')
  } catch (err) {
    return errorResponse({ httpCode: 401, httpReason: 'Unauthorized', details: err })
  }
}

/*
let router = function(verb, path, call) {
  callback(req, res)
}
router('get', '/gatekeeper/admin/api/{whitelistId}', function(req, res) {
})
*/

function getWhitelist(req, res) {
  let whitelistFile = req.path.match(/^\/gatekeeper\/admin\/api\/whitelist\/([^\/]+)$/)[1]

  let opts = { method: 'GET', target: config.BASEDIR+'/whitelist/'+whitelistFile }
  urlopen.open(opts, function(error, response) {
    if (error) return errorResponse({ httpCode: 500, httpReason: 'Internal Server Error', details: error })
    if (response.statusCode != 200) return errorResponse({ httpCode: response.statusCode, httpReason: response.reasonPhrase, details: response })

    response.readAsBuffer(function(error, data) {
      if (error) return errorResponse({ httpCode: 500, httpReason: 'Internal Server Error', details: error })

      data = data.toString().replace(/\s*$/, '').split(/[\s]+/)
      res.status('200 OK')
      res.headers('Content-Type', 'application/json')
      res.send({
        whitelistFile: whitelistFile,
        data: data
      })
    })
  })
}

function updateWhitelist(req, res) {
  res.status('200 OK')
  res.headers('Content-Type', 'application/json')
  res.send({
    message: 'update'
  })
}

function displayPage() {
  let opts = {
    method: 'GET',
    target: config.BASEDIR+'/admin/index.html'
  }
  urlopen.open(opts, function(error, response) {
    response.readAsBuffer(function(error, data) {
      data = data.toString()
      res.status('200 OK')
      res.headers('Content-Type', 'text/html')
      res.send(data)
    })
  })
  
  res.status('200 OK')
  res.headers('Content-Type', 'text/html')
  res.send('<html><body><h1>Admin</h1></body></html>')
}

if ( /^\/gatekeeper\/admin\/api\/whitelist\/[^\/]+$/.test(req.path) ) {
  authenticate()
  switch (req.method) {
    case 'get': {
      getWhitelist(req, res)
      break
    }
    case 'put': {
      updateWhitelist(req, res)
      break
    }
  }
} else if ( /^\/gatekeeper\/admin\/index\.html$/.test(req.path) ) {
  displayPage()
} else {
  res.status('404 Not Found')
}




