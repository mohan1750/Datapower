module.exports = {
/* Customer Profile */
  '/customer-profile/{id}/leads': {
    'get': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/external-identifier': {
    'put': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile': {
    'get': {
      'responseFilter': 'filter-custprof-response-byCustomerId.js' // filter response by customerId in response body - body[].customerId
    },
    'post': {}
  },
  '/customer-profile/{id}/employment': {
    'post': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/privacy-settings': {
    'post': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/email-address': {
    'post': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/accounts/addresses/{usage}': {
    'put': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/phone-numbers': {
    'post': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/phone-numbers/{type}': {
    'put': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/contacts/{sequence}': {
    'put': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}': {
    'get': {
      'requestFilter': 'filter-custprof-byId.js' // filter by customerId in request path - path.id
    }
  },
  '/customer-profile/{id}/accounts': {
    'get': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/contacts': {
    'get': {
      'requestFilter': 'filter-custprof-byId.js'
    },
    'post': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/addresses': {
    'get': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },
  '/customer-profile/{id}/addresses/{usage}': {
    'put': {
      'requestFilter': 'filter-custprof-byId.js'
    }
  },


/* Cards */
  '/card-accounts': {
    'post': {
      'requestFilter': 'filter-cards-byCustomerId.js', // filter by customerId in request body - body.customer.id
      '___responseFilter': 'filter-cards-response-addCardAccountNumber.js' // add accountNumber from body to cardAccountNumbers whitelist - body.accountNumber
    }
  },
  '/card-accounts/details': {
    'post': {
      'requestFilter': 'filter-cards-byCardAccountNumber.js' // filter by accountNumber in request body - body.accountNumber
    }
  },
  '/card-accounts/pricing-controls': {
    'put': {
      'requestFilter': 'filter-cards-byCardAccountNumber.js' // filter by accountNumber in request body - body.accountNumber
    }
  },
  '/credit-cards': {
    'post': {
      'requestFilter': 'filter-cards-byCardAccountNumber.js' // filter by accountNumber in request body - body.accountNumber
    }
  },
  '/cards/active': {
    'put': {
      'requestFilter': 'filter-cards-byCardNumber.js' // filter by cardNumber in request body - body.cardNumber
    }
  },


/* Balances and Transactions */
  '/transactions/retail': {
    'get': {
      'requestFilter': 'filter-btr-byAccountNumber.js' // filter by accountNumber in request query string - query.accountNumber
    }
  },


/* Deposit Accounts */
  '/deposit-accounts/{accountNumber}': {
    'get': {
      'requestFilter': 'filter-depacct-byAccountNumber.js' // filter by accountNumber in request path - path.accountNumber
    }
  },
  '/deposit-accounts': {
    'post': {
      'requestFilter': 'filter-depacct-byCustomerId.js' // filter by customerId in request body - body.customers[].customerId (all in array)
    }
  },

/****************************************************/

/* Account Restraints */
  '/api/accounts/{key}/restraints': {
    'post': {
      'requestFilter': 'filter-accres-byAccountKey.js' // filter by key (acctType and acctNum) in request path - path.key
    }
  },


/* Payments */
  '/payment/transfers': {
    'post': {
      'requestFilter': 'filter-pay-byAccountNumber.js' // filter by accountNumber in request body - body.fromAccountNumber
    }
  },


/* Securities */
  '/securities/{securityNumber}': {
    'put': {
      'requestFilter': 'filter-sec-byAccountNumberInBody.js' // filter by accountNumber in request body - body.relatedAccount.accountNumber
    }
  },
  '/securities': {
    'post': {
      'requestFilter': 'filter-sec-byAccountNumberInBody.js' // filter by accountNumber in request body - body.relatedAccount.accountNumber
    }
  },
  '/accounts/{accountNumber}/security-summary': {
    'get': {
      'requestFilter': 'filter-sec-byAccountNumberInPath.js' // filter by accountNumber in request path - path.accountNumber
    }
  },


/* Document Management */
  '/documentsinfo': {
    'get': {
      'responseFilter': 'filter-doc-response-byCustomerId.js' // filter by customerId in search result response body - body[].customerId
    }
  },
  '/documents/{objectId}': {
    'get': {
      'responseFilter': 'filter-doc-response-documentByCustomerId.js' // filter by customerId in response body - body.customerId
    }
  },
  '/documents': {
    'post': {
      'requestFilter': 'filter-doc-request-restrictDocUpload.js' // filter by customerId in response body - body.customerId
    }
  },


/* Account Summaries 1.0.0 */
  '/api/account-summaries': {
    'get': {
      'requestFilter': 'filter-acctsumm-request-byAccountNumbers.js' // filter request by accountNumbers in query string - query.id
    }
  },

/* Credit Decisioning 1.0.0 */
  '/credit-decision': {
    'post': {}
  },
}

