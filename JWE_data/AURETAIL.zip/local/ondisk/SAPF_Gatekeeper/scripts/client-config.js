let clientIdMap = {
/* Vendor config below */
  'f1054c5d-ece1-46f9-9600-263c13715484': {
    name: 'ACCENTURE',
    env: 'sit'
  },
  'b84f1277-8c11-4c01-a272-4df81a61c929': {
    name: 'ACCENTURE',
    env: 'sit03'
  },
  'a52d9a5a-6adf-49aa-a8e0-39403d8c9e6e': {
    name: 'CAPGEMINI',
    env: 'sit'
  },
  '203775ac-401f-4fed-afac-fa5652bc017f': {
    name: 'CAPGEMINI',
    env: 'sit03'
  },



/* SIT Test client ids */
  'd6b453f9-4531-4417-8ec4-db30b205884c': {
    name: 'SAPF-VND-1',
    env: 'sit',
  },
  '705a7dc0-07ca-4231-99da-b2d9af2efa5c': {
    name: 'SAPF-VND-1',
    env: 'sit03',
  },
  '580fadd8-0d3e-460a-aa28-9ec97fb3cdcc': {
    name: 'SAPF-VND-2',
    env: 'sit',
  },
  'b42e5539-e618-4f71-8c7b-d3f2724eeefd': {
    name: 'SAPF-VND-2',
    env: 'sit03',
  },


///*
// Dev config below
  '89ed7a92-de17-41a1-8c2a-4d4318278093': {
    name: 'SAPF-VND-1',
    env: 'sb',
  },
  '4d3367e7-2be0-41b5-8f55-bf390aef1ffb': {
    name: 'SAPF-VND-1',
    env: 'st',
  },
  '1a9582b3-36c5-416c-831c-437c668d3e43': {
    name: 'SAPF-VND-2',
    env: 'sb',
  },
  '46d463b9-1fca-4fb6-b0b0-3b1e9832d2c4': {
    name: 'SAPF-VND-2',
    env: 'st',
  },
  'abcdefg': {
    name: 'vendor-3',
    env: 'sit',
  },

// Tosca config below
  '7b1f7ec1-abc8-4b62-aa47-60cca974aab5': {
    name: 'SIT-APP-1',
    env: 'sit'
  },
  'c84c28b4-1967-46bb-b6de-69878bf3e275': {
    name: 'SIT-APP-2',
    env: 'sit'
  }
//*/
}


let clientDetails = {
  'ACCENTURE': {
    subs: [
      'sapf-mule-d1@simplify.accenture.com',
      'sapf-mule-poc@simplify.accenture.com',
      'sapf-mule-t1@simplify.accenture.com',
      'sapf-mule-t2@simplify.accenture.com'
    ],
    jwks: {
      keys: [
        {
          alg: "RS256",
          e: "AQAB",
          n: "hINglez11Ax27kLQL1SCN8YLB2IS89xETE47CkpM50d4OWWGEc3AwV6kRTtRIzbpece0m1YwlMr9G4rMLxKwom9raV6TKlc7OLURCbg9QhE6pnHZ9WnzSPIQivUowatSRS6oq3vAK38Ha8zHLg4T3USHQjOLLG82nUNMlKhh1GenkzEF3qN-B6CcfoLJ_gSS3AUcPb9fAuyU8f_kJELd8X9U1SYqF0OeqGf9LRNmRJptXNpwGhgsmuiB2KxnlXbG6F75alZ4Jhml1lqk57KTeBF5ciZzkZtgG-toW_VB9QteFufimDGfy-GSHLtsK6HP4o0pwqIT53MljMh7KGxkxw",
          kid: "YTt0fZ5TqR3QdqNyUr1VaTWXQRRB5G4F3ogC6_CyEpI",
          kty: "RSA",
          use: "sig"
        }
      ]
    }
  },
  'CAPGEMINI': {
    subs: [
      'sapf-mule-admin@simplify.capgemini.com'
    ],
    jwks: {
      keys: [
        {
          alg: "RS256",
          e: "AQAB",
          n: "ojQxCrh4BAasaypocTMaitW5ZpkZSjBNBtUflVP-z40aVAOXMQ1gsIM6lrfuiVRJ7f7qvXCsrtBWZQB1kyujDfq42r5jc0PZiwC3rUryNMXnDSy50ZAL17QUdOfg4NQ52dezP_UUP57rdgGQh-Y43yy6bqdzTQ1NOCSfR9PdElUlB1nDryVz6sQsNQtx-4JBtck9vOpY49VDHTLDr7vHCJmelqHbuTsdGBeJ-0jB6Cx0yQPYdEM81vH9k_kLNlSa6YX129Yw02VXuwsGiLa6uft3pLj2b1rai-PzAn2PVkuv6ziu8NidnatKOXXuFS5Cg-F8zTyoXaXwukfxYKh1cQ",
          kid: "fRUutU4jVGyFleJjHeSu-VcPrfC6bl7JOxcaSw_wWWY",
          kty: "RSA",
          use: "sig"
        }
      ]
    }
  },



  'SAPF-VND-1': {
    subs: [
      'audpclient02.dev.anz'
    ],
    jwks: {
      keys: [
        {
          "kid": "tgdaapitestcc.apps.anz",
          "alg": "RS256",
          "kty": "RSA",
          "use": "sig",
          "e": "AQAB",
          "n": "qbljb573O-H29C9wE7j6pWQUaVmh5U3dQWx3QGXK_6OZBdOHbM4qV1q_N5lL8blPUKF6Jn8RFVtFYFCPTfZYpsiGKcvQIyIa6o1iBv30pEZaLPZGxDyYN3kwuR4sL1MNhzPc0-z1f8yJhyNl-DVGoxGPURd39clJrl6h-AJlohN8ZxW5K9437knJKQQm5jHaI1Iejq4PRJxCxaAxNQd4i6gnaVVY_GTXg2NARDXwuabD463q7NY6pQvzGVJhbYoFEruRSpN6_asfv_4uikKwJJH-egokTeVXyPiy2dAGEL46sIEnVuDTvcBtBm0l92Z4JO5OLlqjMDRAeY28aCA0sw"
        }
      ]
    }
  },
  'SAPF-VND-2': {
    subs: [
      'audpclient02.dev.anz'
    ],
    jwks: {
      keys: [
        {
          "kid": "tgdaapitestcc.apps.anz",
          "alg": "RS256",
          "kty": "RSA",
          "use": "sig",
          "e": "AQAB",
          "n": "qbljb573O-H29C9wE7j6pWQUaVmh5U3dQWx3QGXK_6OZBdOHbM4qV1q_N5lL8blPUKF6Jn8RFVtFYFCPTfZYpsiGKcvQIyIa6o1iBv30pEZaLPZGxDyYN3kwuR4sL1MNhzPc0-z1f8yJhyNl-DVGoxGPURd39clJrl6h-AJlohN8ZxW5K9437knJKQQm5jHaI1Iejq4PRJxCxaAxNQd4i6gnaVVY_GTXg2NARDXwuabD463q7NY6pQvzGVJhbYoFEruRSpN6_asfv_4uikKwJJH-egokTeVXyPiy2dAGEL46sIEnVuDTvcBtBm0l92Z4JO5OLlqjMDRAeY28aCA0sw"
        }
      ]
    }
  }
}

module.exports = {
  clientIdMap: clientIdMap,
  clientDetails: clientDetails
}

