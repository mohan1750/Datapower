module.exports = {
  'BASEDIR': 'local:///ondisk/SAPF_Gatekeeper',
  'hosts': {
    'sb': 'https://apidev.corp.dev.anz',
    'st': 'https://apiau182devgwy01-front.dev.anz/eapicorp01/st',
    'sit': 'https://apisit.corp.dev.anz',
    'sit02': 'https://apisit02.corp.dev.anz',
    'sit03': 'https://apisit03.corp.dev.anz'
  },
  'eventSink': {
    'host': 'https://apisit.corp.dev.anz',
    'clientId': '3827e514-0207-43c2-9c7d-0d9ec08b3969'
  }
}