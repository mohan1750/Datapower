console.error('SAPF Error')
const hm = require('header-metadata');
//const sm = require ('service-metadata');

const res = {
  status: function(sts) { hm.response.statusCode = sts },
  headers: function(name, value) { hm.response.set(name, value) },
  send: function(data) { session.output.write(data) }
}

let ctxANZDP = session.name('ANZDP')
let config = ctxANZDP.getVar('config')
let utils = require(config.BASEDIR+'/scripts/utils')

utils.log('error', '')

let ctxANZERROR = session.name('ANZERROR')
if (ctxANZERROR) {
  let errorDetails = ctxANZERROR.getVar('error')

  utils.log('error', errorDetails)

  res.status(errorDetails.httpCode + ' ' + errorDetails.httpReason)
  res.headers('Content-Type', 'application/json')
  res.send(errorDetails)
} else {
  let sm = require ('service-metadata')
  utils.log('error-sm', sm)
  utils.log('error-errorCode', sm.errorCode)
  utils.log('error-errorMessage', sm.errorMessage)

  res.status('500 Internal Server Error')
  res.headers('Content-Type', 'application/json')
  res.send({
    'details': 'Gatekeeper Error'
  })
}

