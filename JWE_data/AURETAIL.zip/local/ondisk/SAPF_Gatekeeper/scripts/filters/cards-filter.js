const whitelist = {
  'SIT-APP-1': {
    'sit': {
      'cardNums': [
        '0377766000967068',
        '4564807004062038',
        '4564699016942616',
        '4564807012630750',
        '4072209018296972',
      ]
    },
    'sit02': {
      'cardNums': []
    }
  },
  'SIT-APP-2': {
    'sit': {
      'cardNums': [
        '4509499226490177',
        '4072200015071443',
        '4072209018296980',
        '4072209018306078',
        '4072209018306086',
      ],
    },
    'sit02': {
      'cardNums': []
    }
  },

/* Dev config follows */
  'SAPF-VND-1': {
    'sb': {
      'cardNums': [
        '4564621011008284',
        '1111111111111111',
      ]
    },
    'st': {
      'cardNums': [
        '1234567890123456',
      ]
    },
    'sit': {
      'cardNums': [
        '4564621011008285'
      ]
    },
    'sit03': {
      'cardNums': [
        '123456'
      ]
    }
  },
  'SAPF-VND-2': {
    'sb': {
      'cardNums': [
        '1111222233334444',
        '666',
      ]
    },
    'st': {
      'cardNums': [
        '1234123412341234',
      ]
    },
    'sit': {
      'cardNums': [
        '4444111122223333'
      ]
    },
    'sit03': {
      'cardNums': [
        '2222111122223333'
      ]
    }
  }
}

module.exports = function (req, vendor) {
  let cardNum
  try {
    cardNum = JSON.parse(req.body.toString()).cardNumber
  } catch (err) {
    console.error('SAPF Gatekeeper: Error parsing request body', err)
    console.error('Failing request', req)
    return false
  }

  //console.error('--->', whitelist[vendor.name][vendor.env]['cardNums'])

  return (
    whitelist[vendor.name] &&
    whitelist[vendor.name][vendor.env] &&
    whitelist[vendor.name][vendor.env]['cardNums'] &&
    (whitelist[vendor.name][vendor.env]['cardNums'].indexOf(cardNum) > -1)
  )
}
