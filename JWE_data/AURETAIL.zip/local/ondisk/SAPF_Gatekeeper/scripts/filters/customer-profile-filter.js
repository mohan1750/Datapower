const whitelist = {
  'SIT-APP-1': {
    'sit': {
      'custIds': [ '4024876710', '4024876715', '4024868963', '4024868964' ],
      'searchQuery': [ 'name:ANGELINA JOLIE', 'name:KIM ASHLEY', 'name:KEVIN STUTE', 'name:LYNDA DANIEL', 'name:KRISTY JAMES', 'name:*ACCOUNT ACCOUNTING GROUP CLG', 'acct:401471436', 'crn:551278364' ]
    },
    'sit02': {
      'custIds': [],
      'searchQuery': []
    }
  },
  'SIT-APP-2': {
    'sit': {
      'custIds': [ '4024876776', '4024876781', '4024868965', '4024868966' ],
      'searchQuery': [ 'name:DANIEL', 'name:KRISTY JAMES', 'name:*TAT TRUST', 'name:JAMES', 'name:KEVIN STUTE', 'name:HENRY', 'acct:401472682', 'crn:551287381' ]
    },
    'sit02': {
      'custIds': [],
      'searchQuery': [ 'crn:123' ]
    }
  },

/* Dev config below */
  'SAPF-VND-1': {
    'sb': {
      'custIds': [ '123', '456', '789', ],
      'searchQuery': [ 'crn:123' ]
    },
    'st': {
      'custIds': [ '111', '222', '333', ],
      'searchQuery': [ 'crn:123' ]
    },
    'sit': {
      'custIds': [ '4024868931' ]
    },
    'sit03': {
      'custIds': []
    }
  },
  'SAPF-VND-2': {
    'sb': {
      'custIds': [ 'abcd', '666', ],
      'searchQuery': [ 'crn:123' ]
    },
    'st': {
      'custIds': [],
      'searchQuery': [ 'crn:123' ]
    },
    'sit': {
      'custIds': []
    },
    'sit03': {
      'custIds': []
    }
  }
}

module.exports = function (req, vendor) {
  let custId = (req.params && req.params.path && req.params.path.id) || null

  if (custId) {
    // common filter criteria for all operations for individual customer-profile resources
    return (
      whitelist[vendor.name] &&
      whitelist[vendor.name][vendor.env] &&
      whitelist[vendor.name][vendor.env]['custIds'] &&
      (whitelist[vendor.name][vendor.env]['custIds'].indexOf(custId) > -1)
    )
  } else {
    switch (req.method) {
      case 'get': {
        // filter criteria for get customer-profile
        let searchQuery = (req.params && req.params.query && req.params.query.q) || null
        return (
          whitelist[vendor.name] &&
          whitelist[vendor.name][vendor.env] &&
          whitelist[vendor.name][vendor.env]['searchQuery'] &&
          (whitelist[vendor.name][vendor.env]['searchQuery'].indexOf(searchQuery) > -1)
        )
        break
      }
      case 'post': {
        // filter criteria for create customer-profile
        return true
        break
      }
    }
  }
}
