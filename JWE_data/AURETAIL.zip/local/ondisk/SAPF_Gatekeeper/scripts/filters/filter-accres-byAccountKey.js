module.exports = function (req, vendor, callback) {
  let allowed, allowedAccountNumbers
  let accountKey = (req.params && req.params.path && req.params.path.key)

  if (typeof accountKey == 'undefined') {
    console.error('SAPF Gatekeeper: Invalid account Key in path')
    console.error('Failing request', req)
    return callback('Invalid account Key in path')
  }

  if (accountKey.split('-').length != 2) {
    allowed = false
    if (!allowed) console.error('Invalid data access', accountKey, allowedAccountNumbers)
    return callback(null, allowed)
  }

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')

  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_accountNumbersDDA.csv'
  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedAccountNumbers = data.toString().split(/\s+/)
    accountKey = accountKey.split('-')
    let acctType = accountKey[0]
    let acctNum = accountKey[1]

    allowed = (acctType == 'DDA') && ( acctNum && allowedAccountNumbers && (allowedAccountNumbers.indexOf(acctNum) > -1) )
    if (!allowed) console.error('Invalid data access', accountKey, allowedAccountNumbers)
    callback(null, allowed)
  })
}





