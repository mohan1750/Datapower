module.exports = function (req, vendor, callback) {
  let allowed, acctNums, allowedAcctNums
  acctNums = (req.params && req.params.query && req.params.query.id) //accountIds

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')
  let utils = require(config.BASEDIR+'/scripts/utils')

  if (typeof acctNums == 'undefined') {
    utils.log('filter-query-error', 'Error getting acctNums from query')
    return callback('Error getting acctNums from query')
  }
  acctNums = acctNums.replace(/(^,)|(,$)/g, '').split(',')

  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_accountNumbersDDA.csv'
  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedAcctNums = data.toString().split(/\s+/)

    utils.log('filter-acctNums', acctNums)
    utils.log('filter-allowedAcctNums', allowedAcctNums)

    if (acctNums && allowedAcctNums) {
      allowed = acctNums.every(function(item) { return allowedAcctNums.indexOf(item) > -1 })
    }

    if (!allowed) {
      utils.log('filter-invalid', 'not white-listed')
    }

    callback(null, allowed)
  })
}
