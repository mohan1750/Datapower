module.exports = function (req, vendor, callback) {
  let allowed, acctNum, allowedAcctNums
  acctNum = (req.params && req.params.query && req.params.query.accountNumber)

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')

  if (typeof acctNum == 'undefined') {
    console.error('SAPF Gatekeeper: Error getting acctountNum from query')
    console.error('Failing request', req)
    return callback('Error getting acctountNum from query')
  }

  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_accountNumbersDDA.csv'
  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedAcctNums = data.toString().split(/\s+/)
    allowed = ( acctNum && allowedAcctNums && (allowedAcctNums.indexOf(acctNum) > -1) )

    if (!allowed) console.error('Invalid data access', acctNum, allowedAcctNums)

    callback(null, allowed)
  })
}
