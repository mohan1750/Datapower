module.exports = function (res, vendor, callback) {
  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')
  let allowedCustIds

  let apiBody, cardAccountNumber
  try {
    apiBody = JSON.parse(res.body)
  } catch (err) {
    console.error('error parsing API repsonse as JSON', res.body)
    callback('error parsing API repsonse as JSON')
  }

  //callback(null, res)

  const urlopen = require('urlopen')
  let options = {
//    target: 'local:///ondisk/SAPF_Gatekeeper/test.txt',
    target: 'temporary:///test.txt',
    method: 'POST',
    data: 'abcd'
  }
  console.error('Trying to append to', options)

  urlopen.open(options, function(error, response) {
    console.error('error:', error)
    console.error('urlopen done')

    response.readAsBuffer(function(error, responseData) {
      res.body = responseData
      callback(null, res)
    })
  })
/*
  cardAccountNumber = apiBody.httpCode
  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_cardAccountNumbers.csv'

    fs.readFile(whitelistFile, function(error, data) {
      console.error('Read whitelistFile file:', whitelistFile)
      if (error) return callback(error)
      console.error('cardAccountNumbers whitelist ', data.toString().split(/\s+/))

      whitelistFile = 'temporary:///test.txt'
      whitelistFile = 'local:///ondisk/SAPF_Gatekeeper/test.txt'
      console.error('Trying to append to', whitelistFile)
      fs.appendFile(whitelistFile, ' - hello world', function(error) {
        console.error('error:', error)
        console.error('Added cardAccountNumber "'+cardAccountNumber+'" to whitelist - "'+whitelistFile+'"')
        callback(null, { body: data.toString().split(/\s+/) })
      })
    })
*/
/*
    cardAccountNumber = apiBody.httpCode
    const fs = require('fs')
    let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_cardAccountNumbers.csv'

    console.error('Trying to read whitelist - "'+whitelistFile+'"')
    fs.readFile(whitelistFile, function(error, data) {
      if (error) console.error(error)
      console.error('cardAccountNumbers whitelist ', data.toString().split(/\s+/))
    })

    console.error('Trying to add cardAccountNumber "'+cardAccountNumber+'" to whitelist - "'+whitelistFile+'"')

    fs.appendFile(whitelistFile, cardAccountNumber, function(error, data) {
      if (error) {
        console.error('Error adding cardAccountNumber "'+cardAccountNumber+'" to whitelist - "'+whitelistFile+'"')
        apiBody.gatekeeperError = {
          message: 'accountNumber not added to whitelist, contact API team',
          error: error
        }
      } else {
        console.error('Added cardAccountNumber "'+cardAccountNumber+'" to whitelist - "'+whitelistFile+'"')
      }
      let gatekeeperResponse = {
        body: apiBody
      }
      callback(null, gatekeeperResponse)
    })
*/
/*
  if (!apiBody.accountNumber) {
    callback(null, res)
  } else {
    // new account created and accountNumber returned, add to whitelist
    cardAccountNumber = apiBody.accountNumber

    const fs = require('fs')
    let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_cardAccountNumbers.csv'

    fs.appendFile(whitelistFile, cardAccountNumber, function(error, data) {
      if (error) {
        console.error('Error adding cardAccountNumber "'+cardAccountNumber+'" to whitelist - "'+whitelistFile+'"')
        apiBody.gatekeeperError = {
          message: 'accountNumber not added to whitelist, contact API team',
          error: error
        }
      } else {
        console.error('Added cardAccountNumber "'+cardAccountNumber+'" to whitelist - "'+whitelistFile+'"')
      }
      let gatekeeperResponse = {
        body: apiBody
      }
      callback(null, gatekeeperResponse)
    })
  }
*/
}
