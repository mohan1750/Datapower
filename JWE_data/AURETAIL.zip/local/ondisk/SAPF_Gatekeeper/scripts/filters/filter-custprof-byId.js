module.exports = function (req, vendor, callback) {
  let allowed, allowedCustIds
  let custId = (req.params && req.params.path && req.params.path.id)

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')

  if (typeof custId == 'undefined') {
    console.error('SAPF Gatekeeper: Error getting customer Id from path')
    console.error('Failing request', req)
    return callback('Error getting customer Id from path')
  }

  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_customerIds.csv'
  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedCustIds = data.toString().split(/\s+/)
    allowed = ( custId && allowedCustIds && (allowedCustIds.indexOf(custId) > -1) )

    if (!allowed) console.error('Invalid data access', custId, allowedCustIds)

    callback(null, allowed)
  })
}
