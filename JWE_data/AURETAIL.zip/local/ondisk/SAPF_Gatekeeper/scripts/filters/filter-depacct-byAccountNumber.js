module.exports = function (req, vendor, callback) {
  let allowed, allowedDDAIds
  let dda = (req.params && req.params.path && req.params.path.accountNumber)

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')

  if (typeof dda == 'undefined') {
    console.error('SAPF Gatekeeper: Error getting Account Id from path')
    console.error('Failing request', req)
    return callback('Error getting customer Id from path')
  }

  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_accountNumbersDDA.csv'
  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedDDAIds = data.toString().split(/\s+/)
    allowed = (dda && allowedDDAIds && (allowedDDAIds.indexOf(dda) > -1) )

    if (!allowed) console.error('Invalid data access', dda, allowedDDAIds)

    callback(null, allowed)
  })
}





