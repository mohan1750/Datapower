module.exports = function (req, vendor, callback) {
  let allowed = false, customerIds, allowedCustomerIds

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')

  try {
    customerIds = JSON.parse(req.body.toString()).customers.map(function(item) {
      return item.customerId
    })
  } catch (err) {
    console.error('SAPF Gatekeeper: Error getting customer ids from request body', err)
    console.error('Failing request', req)
    return callback('Error parsing request body')
  }

  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_customerIds.csv'
  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedCustomerIds = data.toString().split(/\s+/)

    if (customerIds && allowedCustomerIds) {
      allowed = customerIds.every(function(item) { return allowedCustomerIds.indexOf(item) > -1 })
    }

    if (!allowed) console.error('Invalid data access', customerIds, allowedCustomerIds)

    callback(null, allowed)
  })
}
