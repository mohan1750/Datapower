module.exports = function (req, vendor, callback) {
  let allowed = false, customerId, allowedCustomerIds

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')

  try {
    customerId = JSON.parse(req.body.toString()).customerId
  } catch (err) {
    console.error('SAPF Gatekeeper: Error parsing request body', err)
    console.error('Failing request', req)
    return callback('Error parsing request body')
  }

  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_customerIds.csv'
  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedCustomerIds = data.toString().split(/\s+/)
    allowed = ( customerId && allowedCustomerIds && (allowedCustomerIds.indexOf(customerId) > -1) )

    if (!allowed) {
      console.error('Invalid data access', customerId, allowedCustomerIds)

      session.output.attachment.write(0, '', function(error) {
        if (error) {
          return callback(error)
        }
        return callback(null, allowed)
      })
    } else {
      callback(null, allowed)
    }
  })
}
