module.exports = function (res, vendor, callback) {
  let allowedCustIds

  let apiBody, filteredBody = []
  try {
    apiBody = JSON.parse(res.body)
  } catch (err) {
    console.error('error parsing API repsonse as JSON', res.body)
    callback('error parsing API repsonse as JSON')
  }

  if (Array.isArray(apiBody)) {
    let ctxANZDP = session.name('ANZDP')
    let config = ctxANZDP.getVar('config')

    const fs = require('fs')
    let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_customerIds.csv'
    fs.readFile(whitelistFile, function(error, data) {
      if (error) return callback(error)

      allowedCustIds = data.toString().split(/\s+/)

      console.error('--->allowedCustIds', whitelistFile, allowedCustIds)
      if (allowedCustIds) {
        apiBody.forEach(function(document) {
          console.error('--->document.customerId', document.customerId)
          if (allowedCustIds.indexOf(document.customerId) > -1) {
            filteredBody.push(document)
          }
        })
      }
      let gatekeeperResponse = {
        body: filteredBody
      }

      callback(null, gatekeeperResponse)
    })
  } else {
    callback(null, res)
  }
}
