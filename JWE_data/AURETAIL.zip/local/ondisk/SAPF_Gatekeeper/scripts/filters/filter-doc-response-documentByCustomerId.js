module.exports = function (res, vendor, callback) {
  let customerId, allowedCustIds, body, allowed = false

  try {
    body = JSON.parse(res.body)
  } catch (err) {
    console.error('error parsing API repsonse as JSON', res.body)
    callback('error parsing API repsonse as JSON')
  }
  customerId = body && body.customerId

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')

  //session.name('INPUT').getVar('attachmentManifest')
/*
  session.name('B2BOP').attachment.get(function(error, attach) {
    console.error('---> B2BOP.attachment.get', attach)
    attach.forEach(function(item) {
      console.error('cid:', item['Content-ID'])
      session.output.attachment.write('cid:'+item['Content-ID'], '', function(error) {
        if (error) console.error('--->write error', error)
        console.error('--->wrote attachment')
      })
    })
  })
*/

  let gatekeeperResponse = {}
  if (customerId) {
    const fs = require('fs')
    let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_customerIds.csv'
    fs.readFile(whitelistFile, function(error, data) {
      if (error) return callback(error)

      allowedCustIds = data.toString().split(/\s+/)
      allowed = (allowedCustIds && (allowedCustIds.indexOf(customerId) > -1) )

      if (!allowed) {
        console.error('Invalid data access', customerId, allowedCustIds)
        gatekeeperResponse.statusCode = 404
        gatekeeperResponse.body = { 'error': 'not found' }

        //session.input.deleteVariable('attachment') //.attachment.write()
        //session.output.attachment.remove(0, 'Content-ID', function(error) {})
        session.output.attachment.write(0, '', function(error) {
          if (error) {
            console.error('--->write error', error)
            return callback(error)
          }
          return callback(null, gatekeeperResponse)
        })

      } else {
        // customerId present and allowed
        gatekeeperResponse.body = body
        callback(null, gatekeeperResponse)
      }
    })
  } else {
    // customerId not present at all
    gatekeeperResponse.body = body
    callback(null, gatekeeperResponse)
  }
}
