module.exports = function (req, vendor, callback) {
  let allowed, allowedAccountNumbers, accountNumber

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')

  try {
    accountNumber = JSON.parse(req.body.toString()).fromAccountNumber
  } catch (err) {
    console.error('SAPF Gatekeeper: Error parsing request body', err)
    console.error('Failing request', req)
    return callback('Error parsing request body')
  }

  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_accountNumbersDDA.csv'
  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedAccountNumbers = data.toString().split(/\s+/)
    allowed = (accountNumber && allowedAccountNumbers && (allowedAccountNumbers.indexOf(accountNumber) > -1) )

    if (!allowed) console.error('Invalid data access', accountNumber, allowedAccountNumbers)

    callback(null, allowed)
  })
}





