module.exports = function (req, vendor, callback) {
  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')
  let utils = require(config.BASEDIR+'/scripts/utils')

  let allowed, allowedAccountNumbers, accountNumber, body

  try {
    body = JSON.parse(req.body.toString())
  } catch (err) {
    utils.log('filter-body-parsing-error', err)
    //console.error('Failing request', req)
    return callback('Error parsing request body')
  }
  accountNumber = body && body.relatedAccount && body.relatedAccount.accountNumber
  accountNumber = accountNumber.replace(/^0*/, '')

  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_accountNumbersDDA.csv'
  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedAccountNumbers = data.toString().split(/\s+/)

    utils.log('filter-accountNumber', accountNumber)
    utils.log('filter-allowedAccountNumbers', allowedAccountNumbers)

    allowed = (accountNumber && allowedAccountNumbers && (allowedAccountNumbers.indexOf(accountNumber) > -1) )

    if (!allowed) {
      utils.log('filter-invalid', 'not white-listed')
      //console.error('Invalid data access', accountNumber, allowedAccountNumbers)
    }

    callback(null, allowed)
  })
}

/*
Array.prototype.indexOfAcct = function(accountNumber) {
    for (var i = 0; i < this.length; i++)
        if (pad(this[i],23) === accountNumber)
            return i;
    return -1;
}
*/

function pad(num, size) {
    var s = num+"";
    while (s.length < size) s = "0" + s;
    return s;
}
