module.exports = function (req, vendor, callback) {
  let allowed, allowedAccountNumbers, accountNumber = (req.params && req.params.path && req.params.path.accountNumber)

  if (typeof accountNumber == 'undefined') {
    console.error('SAPF Gatekeeper: Error getting accountNumber from path')
    console.error('Failing request', req)
    return callback('Error getting accountNumber from path')
  }

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')
  const fs = require('fs')
  let whitelistFile = config.BASEDIR+'/whitelist/'+vendor.name+'_'+vendor.env+'_accountNumbersDDA.csv'

  fs.readFile(whitelistFile, function(error, data) {
    if (error) return callback(error)

    allowedAccountNumbers = data.toString().split(/\s+/)
    allowed = (accountNumber && allowedAccountNumbers && (allowedAccountNumbers.indexOf(accountNumber) > -1) )

    if (!allowed) console.error('Invalid data access', accountNumber, allowedAccountNumbers)

    callback(null, allowed)
  })
}
