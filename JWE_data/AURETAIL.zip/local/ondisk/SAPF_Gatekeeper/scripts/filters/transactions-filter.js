const whitelist = {
  'SIT-APP-1': {
    'sit': {
      'acctNums': [ '107507186', '526172341', '197980355' ]
    },
    'sit02': {
      'acctNums': [],
    }
  },
  'SIT-APP-2': {
    'sit': {
      'acctNums': [ '493704435', '452115917' ],
    },
    'sit02': {
      'acctNums': [],
    }
  },

/* Dev config below */
  'SAPF-VND-1': {
    'sb': {
      'acctNums': [ '526172341', '123', '456', '789', ]
    },
    'st': {
      'acctNums': [ '111', '222', '333', ]
    }
  },
  'SAPF-VND-2': {
    'sb': {
      'acctNums': [ 'abcd', '666', ],
    },
    'st': {
      'acctNums': []
    }
  }
}


module.exports = function (req, vendor) {
  let acctNum = req.params.query.accountNumber
  let acctSys = req.params.query.accountSystem

  return (
    whitelist[vendor.name] &&
    whitelist[vendor.name][vendor.env] &&
    whitelist[vendor.name][vendor.env]['acctNums'] &&
    (whitelist[vendor.name][vendor.env]['acctNums'].indexOf(acctNum) > -1) &&
    (acctSys == 'CAP')
  )
}