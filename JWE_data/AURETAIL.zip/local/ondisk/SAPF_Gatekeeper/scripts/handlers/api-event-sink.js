const sm = require ('service-metadata');
const hm = require('header-metadata');

module.exports = function(req, res) {
  let ctxANZDP = session.name('ANZDP')
  let config
  if (ctxANZDP) config = ctxANZDP.getVar('config')

  sm.routingUrl = config.eventSink.host + '/sapf/event-sink'
  sm.protocolMethod = 'POST'

  delete req.headers.Host
  hm.current.set('Content-Type', 'application/json')
  hm.current.set('X-IBM-Client-Id', config.eventSink.clientId)

  let body = req
  session.output.write(body)
}
