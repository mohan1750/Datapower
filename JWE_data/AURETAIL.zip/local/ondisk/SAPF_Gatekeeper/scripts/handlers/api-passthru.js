const sm = require('service-metadata')
const hm = require('header-metadata')


module.exports = function(req, res) {
  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')
  let utils = require(config.BASEDIR+'/scripts/utils')

  //let apiConfig = ctxANZDP.getVar('apiConfig')
  let client = ctxANZDP.getVar('client')
  let apiOpConfig = ctxANZDP.getVar('apiOpConfig')

  let filter
  let allowed = false

  /////////// OPT 2 /////////
  // makes apiConfig very verbose
  // filter = apiConfig.filter
  if (apiOpConfig.requestFilter) {
    utils.log('api-passthru', 'trying to apply filter: '+apiOpConfig.requestFilter)
    filter = require(config.BASEDIR+'/scripts/filters/'+apiOpConfig.requestFilter)
  }

  if ( filter && (typeof filter == 'function') ) {
    filter(req, client, function(error, allowed) {
      if (error) {
        utils.log('error', 'Filter error')
        utils.log('error', error)
        //console.error('-->filter error', error)
      }
      if (allowed) {
        utils.log('api-passthru', 'whitelisted request')

        sm.routingUrl = config.hosts[client.env] + req.path + req.search
        sm.protocolMethod = req.method.toUpperCase()
        delete req.headers.Host

        //req.headers.Host = config.hosts[client.env]
        for (let hdr in req.headers) { hm.current.set(hdr, req.headers[hdr]) }
        //if (req.body) session.output.write(req.body)
        if (req.body && req.body.toString() != '') {
          session.output.write(req.body)
        } else {
          let contentTypeProp = Object.keys(req.headers).filter(function(key) { return key.toLowerCase() == 'content-type' })
          contentTypeProp = contentTypeProp && contentTypeProp[0]
          hm.current.remove('content-type')
        }

      } else {

        utils.log('api-passthru', 'non white-listed request')
        //console.error('SAPF invalid data access')
        //console.error(req)
        //console.error(client)

        sm.mpgw.skipBackside = true
        res.status('404 Not Found')
        res.headers('Content-Type', 'application/json')
        res.send({
          httpCode: 404,
          httpMessage: 'Not Found'
        })
      }
    })
  } else {
    utils.log('api-passthru', 'no filter applied')
    // No filter to be applied
    sm.routingUrl = config.hosts[client.env] + req.path + req.search
    sm.protocolMethod = req.method.toUpperCase()
    delete req.headers.Host

    for (let hdr in req.headers) { hm.current.set(hdr, req.headers[hdr]) }
    if (req.body && req.body.toString() != '') {
      session.output.write(req.body)
    } else {
      let contentTypeProp = Object.keys(req.headers).filter(function(key) { return key.toLowerCase() == 'content-type' })
      contentTypeProp = contentTypeProp && contentTypeProp[0]
      hm.current.remove('content-type')
    }
  }


}




/*
let whitelistTest = [{
  method: 'post',
  path: '/customer-profile/*',
  params: {
    query: {
      valid: ['123', '456', '789']
    },
    path: {
      id: ['123', '456', '789']
    },
    header: {
      'x-valid': ['123', '456', '789']
    },
    body: {
      '$.valid': ['123', '456', '789']
    }
  }
}, {
  method: 'put',
  path: '/cards*',
  params: {
    'query': {
      allCards: ['false']
    }
  }
}]
*/

/*
  let whitelist = require(config.BASEDIR+'/scripts/'+vendor.whitelistFile)
  // TODO
  whitelist = whitelistTest

  // filter out based on whitelist
  let allowed = true
  whitelist.forEach(function(predicate) {
    // method
    if (predicate.method && predicate.method == req.method) {
      allowed = false
    }
    console.error('--->method allowed', allowed)

    console.error('--->predicate.path', predicate.path)
    // path
    if (predicate.path) {
      let pathRegex = predicate.path
*/
//      pathRegex = pathRegex.replace(/\//g, '\/').replace(/{[^}]+}/g, '([^\/]+)').replace(/\*/g, '(.*?)')
/*      pathRegex = '^'+pathRegex+'$'
      pathRegex = new RegExp(pathRegex)

      if (pathRegex.test(req.path)) {
        allowed = allowed && true
      }
      console.error('--->path allowed', allowed)
    }
  })
  console.error('--->final allowed', allowed)
  allowed = true
*/


/*
  /////////// OPT 1 /////////
  // disconnect between apiConfig and selection of filter
  switch (true) {
    case (/^\/customer-profile.*$/.test(req.path)) : {
      filter = require(config.BASEDIR+'/scripts/filters/customer-profile-filter.js')
      break
    }
    case (/^\/cards\/.+?/.test(req.path)) : {
      filter = require(config.BASEDIR+'/scripts/filters/cards-filter.js')
      break
    }
    case (/^\/dda-accounts\/.+?/.test(req.path)) : {
      filter = require(config.BASEDIR+'/scripts/filters/dda-accounts-filter.js')
      break
    }
    case (/^\/transactions$/.test(req.path)) : {
      filter = require(config.BASEDIR+'/scripts/filters/transactions-filter.js')
      break
    }
  }

  if (typeof filter == 'function') allowed = filter(req, client)
  if (allowed) {
    //sm.routingUrlSslprofile = 'Internal_SSLClientProfile_SAPF_Gatekeeper'

    sm.routingUrl = config.hosts[client.env] + req.path + req.search
    sm.protocolMethod = req.method

    delete req.headers.Host
    for (let hdr in req.headers) {
      hm.current.set(hdr, req.headers[hdr])
    }

    if (req.body) {
      session.output.write(req.body)
    }
  } else {
    console.error('SAPF invalid data access')
    console.error(req)
    console.error(client)
    sm.mpgw.skipBackside = true
    res.status('404 Not Found')
    res.headers('Content-Type', 'application/json')
    res.send({
      httpCode: 404,
      httpMessage: 'Not Found'
    })
  }
*/



/*
  const urlopen = require('urlopen')
  let options = {
    target: 'https://apidev.corp.dev.anz' + req.path + req.search,
    method: req.method,
    headers: req.headers,
    data: req.body,
    timeout: 30,
    sslClientProfile: 'Internal_SSLClientProfile_SAPF_Gatekeeper'
  };
  urlopen.open(options, function (urlOpenError, response) {
    if (urlOpenError) {
      console.error('urlopen.open error:', urlOpenError, options)
      res.status('500')
      res.headers('Content-Type', 'application/json')
      res.send({ error: 'URL Open Error' })
      return
    } else {
      response.readAsBuffer(function(readAsBufferError, buffer) {
        if (!readAsBufferError) {
          res.status(response.statusCode+'')
          for (let hdr in response.headers) {
            res.headers(hdr, response.headers[hdr])
          }
          res.send(buffer)
        } else {
          console.error('response.readAsBuffer error:', readAsBufferError, options)
          res.status('500')
          for (let hdr in response.headers) {
            res.headers(hdr, response.headers[hdr])
          }
          res.headers('Content-Type', 'application/json')
          res.send({ error: 'Error reading API response' })
        }
      })
    }
  });
*/
