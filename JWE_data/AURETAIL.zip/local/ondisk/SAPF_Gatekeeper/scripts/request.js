const sm = require ('service-metadata');
const hm = require('header-metadata');

console.options({'category':'sapf'}).log(new Date(), sm.transactionId, 'SAPF Gatekeeper STARTED')


// Bootstrap the application
let config, apiConfig, clientConfig, client, bootstrapped = false
let ctxANZDP
let utils
try {
  config = require('local:///ondisk/SAPF_Gatekeeper/scripts/config')

  utils = require(config.BASEDIR+'/scripts/utils')

  apiConfig = require(config.BASEDIR+'/scripts/api-config.js')
  clientConfig = require(config.BASEDIR+'/scripts/client-config.js')
  bootstrapped = true

  ctxANZDP = session.name('ANZDP') || session.createContext('ANZDP')
  ctxANZDP.setVar('config', config)
  //ctxANZDP.setVar('apiConfig', apiConfig)
} catch (error) {
  console.options({'category':'sapf'}).error(new Date(), sm.transactionId, 'error')
  console.options({'category':'sapf'}).error('Error loading config files')
  console.options({'category':'sapf'}).error(error)

  sm.mpgw.skipBackside = true
  let errorDetails = {
    httpCode: 500,
    httpReason: 'Internal Server Error',
    details: error
  }
  let ctxANZERROR = session.name('ANZERROR') || session.createContext('ANZERROR')
  ctxANZERROR.setVar('error', errorDetails)
  throw new Error()

  //console.error('Error loading config files')
  //console.error(error)
  //return utils.errorResponse({ details: 'Error loading config files' })
}

if (!bootstrapped) {
  sm.mpgw.skipBackside = true
  let errorDetails = {
    httpCode: 500,
    httpReason: 'Internal Server Error',
    details: 'Error bootstrapping Gatekeeper'
  }
  let ctxANZERROR = session.name('ANZERROR') || session.createContext('ANZERROR')
  ctxANZERROR.setVar('error', errorDetails)
  throw new Error()

  //return utils.errorResponse({ details: 'Error bootstrapping' })
}



const method = sm.protocolMethod.toLowerCase();
const url = require('url').parse(sm.URLIn, false)
const headers = hm.current.headers
const txnId = sm.getVar("var://service/transaction-id") // "var://service/global-transaction-id"

let req = {
  method: method,
  path: url.pathname.replace(/\/$/, ''),
  headers: headers,
  params: {},
  urlObj: url,
  url: sm.URLIn,
  protocol: sm.protocol,
  hostname: headers.Host,
  hostip: url.hostname,
  clientip: sm.transactionClient,
  trnId: sm.transactionId,
  routingUrl: sm.routingUrl
}
if (url.query) {
  req.query = url.query
  req.params = req.params || {}
  req.params.query = require('querystring').parse(url.query)
}
req.search = url.search || ''

const res = {
  status: function(sts) { hm.response.statusCode = sts },
  headers: function(name, value) { hm.response.set(name, value) },
  send: function(data) { session.output.write(data) }
}

// Verify client id
utils.log('request', req)

let clientIdProp = Object.keys(req.headers).filter(function(key) { return key.toLowerCase() == 'x-ibm-client-id' })

clientIdProp = clientIdProp && clientIdProp[0]
let clientId = req.headers[clientIdProp]

if (!clientId) {
  return utils.errorResponse({ httpCode: 401, httpReason: 'Unauthorized', details: 'Invalid Client Id' })
}
if (!clientConfig.clientIdMap[clientId]) {
  return utils.errorResponse({ httpCode: 403, httpReason: 'Forbidden', details: 'Invalid Client Id' })
}

client = clientConfig.clientDetails[clientConfig.clientIdMap[clientId].name]
if (!client) { return utils.errorResponse({ httpCode: 500, httpReason: 'Internal Server Error', details: 'Client not configured in Gateway' }) }

client.name = clientConfig.clientIdMap[clientId].name
client.env = clientConfig.clientIdMap[clientId].env
ctxANZDP.setVar('client', client)
utils.log('client', client)


// TODO: FIX THIS!!!
if (! /^\/documents.*$/.test(req.path)) {
  // Verify JWT
  //let authProp = Object.keys(req.headers).find(function(key) { return key.toLowerCase() == 'authorization' })
  let authProp = Object.keys(req.headers).filter(function(key) { return key.toLowerCase() == 'authorization' })
  authProp = authProp && authProp[0]
  let token = req.headers[authProp]

  if ( !token || (token.substr(0, 7) != 'Bearer ') || token.substr(7).split('.').length != 3) {
    return utils.errorResponse({ httpCode: 401, httpReason: 'Unauthorized', details: 'Invalid or Missing Access Token' })
  }
  try {
    token = token.substr(7)
    let tokenParts = token.split('.')
    let tokenClaims = JSON.parse(new Buffer(tokenParts[1], 'base64').toString('utf-8'))
  } catch (err) {
    return utils.errorResponse({ httpCode: 401, httpReason: 'Unauthorized', details: 'Invalid Access Token' })
  }

  const jwt = require('jwt')
  let decoder = new jwt.Decoder(token)
  decoder
    .addOperation('verify', client.jwks)
    .addOperation({ validateDataType: true, validateAudience: false, validateExpiration: true, validateNotBefore: true }, 'validate')
    .decode(function(error, claims) {
      if (error) {
        return utils.errorResponse({ httpCode: 401, httpReason: 'Unauthorized', details: error.errorMessage })
      } else {
        // Validate sub
        if (client.subs.indexOf(claims.sub) < 0) {
          return utils.errorResponse({ httpCode: 403, httpReason: 'Forbidden', details: 'Invalid claim - "sub". Received "'+claims.sub+'"' })
        }
        processRequest()
      }
    })
} else {
  processRequest()
}

function processRequest() {
  let apiMethod = method
  let apiPathConfig = null
  let apiOpConfig = null

  try {
    // try to find request path in listed apis
    for (let pathPattern in apiConfig) {
      let pathRegex = pathPattern
      pathRegex = pathRegex.replace(/\//g, '\/')
      pathRegex = pathRegex.replace(/{[^}]+}/g, '([^\/]+)')
      pathRegex = '^'+pathRegex+'$'
      //pathRegex = new RegExp(pathRegex, 'g')
      pathRegex = new RegExp(pathRegex)

//      if (pathRegex.test(url.pathname)) {
      if (pathRegex.test(req.path)) {
        apiPathConfig = apiConfig[pathPattern]
        req.route = pathPattern

        // create path params object
        let pathValues = req.path.match(pathRegex).splice(1)
        let pathParams = pathPattern.replace(/[{}]/g, '').match(pathRegex).splice(1)
        for ( let i = 0 ; i < pathParams.length ; i++ ) {
          req.params.path = req.params.path || {}
          req.params.path[pathParams[i]] = pathValues[i]
        }
        break
      }
    }
  } catch (err) {
    utils.log('error', 'Error finding route '+req.path)
    utils.log('error', err)
    //console.error('Error finding route', req.path)
    //console.error(err)
    utils.errorResponse({ details: 'Error finding route' })
  }

  // read body if present
  session.input.readAsBuffer(function(error, requestBody) {
    if (error) return utils.errorResponse({ details: 'Could not process request body' })
    req.body = requestBody
    req.bodyStr = requestBody.toString()

    // look for defined apis/routes
    // if path is found, look for method
    let routeHandler
    if (apiPathConfig && apiPathConfig[method]) {
      apiOpConfig = apiPathConfig[method]
      ctxANZDP.setVar('apiOpConfig', apiOpConfig)

      //let apiPassThruHandler = require(config.BASEDIR+'/scripts/handlers/api-passthru.js')
      //apiPassThruHandler(req, res)
      routeHandler = require(config.BASEDIR+'/scripts/handlers/api-passthru.js')
    } else {
      //let eventSinkHandler = require(config.BASEDIR+'/scripts/handlers/api-event-sink.js')
      //eventSinkHandler(req, res)
      routeHandler = require(config.BASEDIR+'/scripts/handlers/api-event-sink.js')
    }
    routeHandler(req, res)
  })
}

