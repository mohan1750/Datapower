var sm = require('service-metadata');
var hm = require('header-metadata');

let res = {}

// Read the input as a Buffer object
session.input.readAsBuffer(function (error, responseBody) {
  if (error) return errorResponse({ details: { error: 'Could not process response body' } })

  res.body = responseBody.toString()
/*
	var ctxANZDP = session.name('ANZDP');
	var acceptVal = ctxANZDP.getVar('accept');
	//hm.current.set('Content-Type', acceptVal);
*/
  //console.error('---->responseBody', responseBody.toString())

  let ctxANZDP = session.name('ANZDP')
  let config = ctxANZDP.getVar('config')
  let client = ctxANZDP.getVar('client')
  let apiOpConfig = ctxANZDP.getVar('apiOpConfig')
  let utils = require(config.BASEDIR+'/scripts/utils')

  if (apiOpConfig) {
    // if whitelisted API, apiOpConfig will exist
    if (apiOpConfig.responseFilter) {
      utils.log('response-filter', 'trying to apply filter: '+apiOpConfig.responseFilter)

      let filter = require(config.BASEDIR+'/scripts/filters/'+apiOpConfig.responseFilter)
      filter(res, client, function(error, filteredResponse) {
        if (error) utils.log('response-filter-error', error)

        utils.log('response-filter', 'applied response filter: '+apiOpConfig.responseFilter)
        if (filteredResponse.statusCode) hm.response.statusCode = filteredResponse.statusCode

        hm.response.set('Content-Type', hm.current.headers['Content-Type'])
        session.output.write(filteredResponse.body)
      })
    } else {
      utils.log('response', 'no response filter to be applied')
      hm.response.set('Content-Type', hm.current.headers['Content-Type'])
      session.output.write(responseBody)
    }
  } else {
    // if non-whitelisted API, response is from SAPF Event Sink, send it as it is
    //session.output.write({ body: responseBody, hm: hm })
    hm.response.set('Content-Type', hm.current.headers['Content-Type'])
    session.output.write(responseBody)
  }

});

function errorResponse(error) {
  hm.response.statusCode = (error.httpCode || '500')+' '+(error.httpReason || 'Internal Server Error')
  hm.response.set('Content-Type', 'application/json')
  session.output.write(error.details || {})
}
