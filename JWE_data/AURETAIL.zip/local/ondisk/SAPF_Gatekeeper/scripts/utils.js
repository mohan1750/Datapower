let log = function(label, data, type) {
  //let ctxANZDP = session.name('ANZDP')
  //let meta = ctxANZDP.getVar('meta')

  type = type || 'log'
  let meta = {
    txnId: require('service-metadata').transactionId
  }
  console.options({'category':'sapf'})[type](new Date(), meta.txnId, label)
  console.options({'category':'sapf'})[type](data)
  console.options({'category':'sapf'})[type]('---------------------')
}

let errorResponse = function(error) {
  require('service-metadata').mpgw.skipBackside = true
  let httpCode = error.httpCode || '500'
  let httpReason = error.httpReason || 'Internal Server Error'
  let errorDetails = {
    httpCode: httpCode,
    httpReason: httpReason,
    details: error.details
  }
  let ctxANZERROR = session.name('ANZERROR') || session.createContext('ANZERROR')
  ctxANZERROR.setVar('error', errorDetails)

  throw new Error()

  //res.status(httpCode + ' ' + httpReason)
  //res.headers('Content-Type', 'application/json')
  //res.send(errorResponse)
}

module.exports = {
  log,
  errorResponse,
}

