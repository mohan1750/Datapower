var jose = require('jose');
var jwt = require('jwt');
var hm = require('header-metadata');

var sub= session.parameters.sub;
var prospectId = session.parameters.prospectId;
var PROSPECT_ID = 'PROSPECT_ID'+ ':' + prospectId;
var crn = session.parameters.crn;
var CRN = 'CRN'+ ':' + crn;
var anzsi = session.parameters.anzsi;
var ANZSI = 'ANZSI'+ ':' + anzsi;

var claims = { 'iat': ((new Date().getTime())-1)/1000, //system date
               'exp': (new Date().getTime() + 900000)/1000,  // expire in 15 min
               'iss': 'datapowersit1.dev.anz',
			   'sub': sub,
			   'aud':'xOLA',
			    'scopes': [
   "AU.RETAIL.ORDER.CREATE",
 "AU.RETAIL.REFERENCE.READ",
 "AU.RETAIL.PRODUCTS.READ",
 "AU.RETAIL.VERIFICATION.ADDRESS.READ",
 "AU.RETAIL.ORDER.UPDATE",
"AU.RETAIL.ORDER.READ",
"AU.RETAIL.VERIFICATION.EV.READ",
"AU.RETAIL.ORDER.TEMPLATE.READ"
  ],
  if (PROSPECT_ID) {
   'roles': [
   CRN,
   PROSPECT_ID
   ],
}
 if (ANZSI) {
   'roles': [
   CRN,
   ANZSI
   ],
}
   
    'acr': 'IAL1.AAL1.FAL1',
  'amr': [],
  'nonce': 'id123456789'
           };


// use RS256 algorithm and crypto key to sign
var jwsHeader=jose.createJWSHeader('dpaau182sit01_key','RS256');
jwsHeader.setProtected({'typ': 'JWT'});
 
var encoder = new jwt.Encoder(claims);

encoder.addOperation('sign', jwsHeader)
       .encode(function(error, token) {
          if (error) {
              session.output.write('error creating JWT: ' + error);
          } else {
              // write the JWT token to output
              //session.output.write(token);
               var Bear = 'Bearer' + ' ' + token;
               hm.current.set('Authorization', Bear);
          }
       }); 
