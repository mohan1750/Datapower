/**
 * write on NFS
 * 
 */

var urlopen = require('urlopen');
var converter = require('json-xml-converter');
var serviceVars = require ( 'service-metadata' ); // import the service variables functions
serviceVars.mpgw.skipBackside = true;             // write to the skipBackside





/*try {*/
	

	// Read the payload as XML
	session.input.readAsXML(function(readError, xml) {
		console.log("reading the request message ++++++++");
		if (readError) {
			session.input.readAsJSON(function(readJsonError, json) {
				if (readJsonError) {
					console.error('Could not parse Request body as JSON');
					session.input.readAsBuffers(function(bufferError, buffer) {
						if (bufferError) {
							console.error('Could not parse Request body')
							//InvalidRequest();
							session.reject('Error on readAsBuffers: ' + bufferError);
						} else {
							process(buffer);
						}
				});
				}else {
					process(json);
				}
			});
		} else {
			process(xml);
		}
	});

	// processing request message

	
/*} catch (error) {
	return APICMQErrorHelper("Gatewayscript error", 400, "Internal error",
			"APICMQ001 : Response code: '" + error,"Please refer to the datapower log for more information");
}
*/

	var targetOpt = {
			url : "dpnfs://ESL_NFS_StaticMount/",
			file : "nestesting.pdf",
			append: false,
		}
	
function process(req) {
	console.log("reading the request message in process ++++++++");
	var options = {
		target : "dpnfs://ESL_NFS_StaticMount/nestesting.pdf?Append=false",
		data : req,
		response: "ignore"
	}
	
	try {
		console
				.error('NFS URL Open: Trying to connect to '
						+ options.target)
		urlopen
				.open("dpnfs://ESL_NFS_StaticMount/nestesting.pdf?Append=false",
						function(connectError, res) {
							if (res) {
								console.critical('Received NFS '
										+ res.statusCode + ' for target '
										+ options.target);
							}
							if (connectError) {
								console
										.error('NFS URL Open: Connection Error for target '
												+ options.target)
								console.error(connectError)
								NoQueueManagerFoundException(2059, "");
							}
							// MQRC = 0
							else if (res.statusCode === 0) {
								// For Datagram messages, send back MQMD as response
								if (mqOpt.msgType === 8) {
									console
											.error("Datagram messages, send back as response");
									
									apic.output('application/json');
									session.output.write("");

								} else {
									res
											.readAsXML(function(
													readAsXMLError, xmlDom) {
												if (readAsXMLError) {
													res
															.readAsJSON(function(
																	readAsJSONError,
																	jsonObj) {
																if (readAsJSONError) {
																	console
																			.error("Unable to read response as XML or JSON");

																	APICMQErrorHelper(
																			"TypeError",
																			400,
																			"Read As JSON or XML Error",
																			"Unable to read response as XML or JSON");

																} else {
																	console
																			.error(
																					'MQ URL Open Response JSON:',
																					jsonObj);
																	apic
																			.output('application/json');
																	session.output
																			.write(jsonObj);
																}
															});
												} else {
													console
															.error(
																	'MQ URL Open Response XML:',
																	xmlDom);
													apic
															.output('application/xml');
													session.output
															.write(xmlDom);
												}
											});
								}
							} else if (res.statusCode === 2085) {
								NoQueueFoundException(2085, "")
							} else if (res.statusCode === 2059) {
								NoQueueManagerFoundException(2059, "")
							} else if (res.statusCode === 2033) {
								ResponseTimeOutException(2033)
							} else {
								var errorMessage = "Thrown error on urlopen.open for target "
										+ options.target
										+ ":   statusCode:"
										+ res.statusCode
								console.error(errorMessage);
								APICMQErrorHelper("Unknown Error", 400,
										errorMessage,
										"Please refer to the datapower log for more information")
							}

						});
	} catch (error) {
		var errorMessage = "Thrown error on urlopen.open for target "
				+ options.target + ": " + error.message
				+ ", error object errorCode=" + error.errorCode.toString();
		console.error("NFS URL Open: Exception for target " + options.target
				+ " Error:" + error);
		APICMQErrorHelper("Unknown Error", 400, errorMessage,
				"Please refer to the datapower log for more information")
	}
}




	function APICMQErrorHelper(name, code, message, details) {

		code = code || 400;

		

	}

	function NoQueueFoundException(responseCode, queue) {
		return APICMQErrorHelper("NoQueueFoundException", 404,
				"Queue Not Found", "APICMQ001 : Response code '" + responseCode
						+ "', Please check the Queue name is correct.");
	}

	function NoQueueManagerFoundException(responseCode, queueManagerObjectName) {
		return APICMQErrorHelper(
				"NoQueueManagerFoundException",
				404,
				"Queue Manager Not Found",
				"APICMQ002 : Response code: '"
						+ responseCode
						+ "', API Connect was unable to find a QueueManager Object with the name '"
						+ queueManagerObjectName + "'");
	}

	function ResponseTimeOutException(responseCode) {
		return APICMQErrorHelper("ResponseTimeOutException", 408, "Timeout",
				"APICMQ004 : Response code: '" + responseCode
						+ "', A response was not received in the given time. ");
	}

	function InvalidSOAPResponse(SOAPResponse) {
		return APICMQErrorHelper(
				"InvalidSOAPResponse",
				400,
				"Invalid SOAP Response",
				"APICMQ005 : Invalid SOAP Response  : Please check the BackOut Queue for the message");
	}

	function InvalidRequest(SOAPResponse) {
		return APICMQErrorHelper(
				"InvalidResponse",
				400,
				"Invalid Request",
				"APICMQ006 : Error occurred when reading the input was the inputData XML or JSON");
	}

	