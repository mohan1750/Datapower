var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require ('service-metadata');


var output = {};
var errorCode = 0;
var errorMsg = '';

// Read the input as a JSON object
session.input.readAsBuffer (function (error, inputRequest) {
    if (error) {
      // an error occurred when parsing the content, e.g. invalid JSON object
      // uncatched error will stop the processing and the error will be logged
      throw error;
    }
	
	var ctxANZDP = session.name('ANZDP');
	errorCode = ctxANZDP.getVar('errorCode');
	errorMsg = ctxANZDP.getVar('errorMsg');
	
	//var acceptVal = ctxANZDP.getVar('accept');
	hm.current.set('Content-Type', 'application/json');
	
	urlopen.open("local:///ondisk/services/IngressMQRouter01/Common/TechnicalErrorMappings.json",ErrorMapping);
});

function ErrorMapping(error,response){
	if (error) {
	   throw error;
	}else{
		response.readAsJSON(function (error, data) {
			var Status = {};					
			Status.errLocation = 'IngressMQRouter01';
                        var ctxANZDP = session.name('ANZDP');
			var ErrorCodes = data.ErrorCodes;
			for(var i in ErrorCodes) {				
				var technicalCode = ErrorCodes[i].technicalCode;
				if(technicalCode.indexOf('default') > -1){
					Status.statusCode = ErrorCodes[i].statusCode;
					Status.severity = ErrorCodes[i].severity;
					Status.statusDesc = ErrorCodes[i].statusDesc + " - " + errorMsg;
					
					hm.current.statusCode = Number(ErrorCodes[i].httpCode);
ctxANZDP.setVar('httpStatusCode',Number(ErrorCodes[i].httpCode));
				}
				
				if(technicalCode.indexOf(errorCode) > -1){
					Status.statusCode = ErrorCodes[i].statusCode;
					Status.severity = ErrorCodes[i].severity;
					Status.statusDesc = ErrorCodes[i].statusDesc + " - " + errorMsg;
					
					hm.current.statusCode = Number(ErrorCodes[i].httpCode);
ctxANZDP.setVar('httpStatusCode',Number(ErrorCodes[i].httpCode));
					break;
				}
			}
			
			output.Status = Status;	
			session.output.write(output);
		});
	}
}