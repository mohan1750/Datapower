var hm = require('header-metadata'); 
var statusCode = hm.response.statusCode;
var reasonPhrase = hm.response.reasonPhrase;
var ctxANZDP = session.name('ANZDP') || session.createContext('ANZDP');;
ctxANZDP.setVar('httpStatusCode',statusCode + ' ' + reasonPhrase);
